package project;
public class Main {
    public static void main(String[] args) throws CloneNotSupportedException {
        CustomerDatabase db = new CustomerDatabase();

        // Adding customers
        db.addCustomer(new Customer(101, "Alice", 5000.50));
        db.addCustomer(new Customer(102, "Bob", 3000.75));
        db.addCustomer(new Customer(103, "Charlie", 7000.00));

        // Display original list
        System.out.println("Original customer list:");
        db.printCustomers();

        // Sort by ID (natural order)
        System.out.println("\nSorted by ID:");
        db.sortCustomers();
        db.printCustomers();

        // Sort by Name
        System.out.println("\nSorted by Name:");
        db.sortCustomers(new NameComparator());
        db.printCustomers();

        // Sort by Balance
        System.out.println("\nSorted by Balance:");
        db.sortCustomers(new BalanceComparator());
        db.printCustomers();

        // Clone a customer
        Customer clonedCustomer = db.iterator().next().clone();
        System.out.println("\nCloned Customer: " + clonedCustomer);
    }
}

