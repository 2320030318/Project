package project;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class CustomerDatabase implements Iterable<Customer> {
    private List<Customer> customers;

    public CustomerDatabase() {
        customers = new ArrayList<>();
    }

    // Add customer to the database
    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    // Sort customers by natural order (by id)
    public void sortCustomers() {
        Collections.sort(customers);
    }

    // Sort customers using a custom comparator (e.g., by balance or name)
    public void sortCustomers(Comparator<Customer> comparator) {
        Collections.sort(customers, comparator);
    }

    @Override
    public Iterator<Customer> iterator() {
        return customers.iterator();
    }

    // Print all customers
    public void printCustomers() {
        for (Customer customer : customers) {
            System.out.println(customer);
        }
    }
}
