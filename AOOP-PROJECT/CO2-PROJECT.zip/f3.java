package project;

import java.util.Comparator;

//Comparator to sort by balance
class BalanceComparator implements Comparator<Customer> {
 @Override
 public int compare(Customer c1, Customer c2) {
     return Double.compare(c1.getBalance(), c2.getBalance());
 }
}

//Comparator to sort by name
class NameComparator implements Comparator<Customer> {
 @Override
 public int compare(Customer c1, Customer c2) {
     return c1.getName().compareTo(c2.getName());
 }
}
