package project;

import java.util.Objects;

public class Customer implements Comparable<Customer>, Cloneable {
    private int id;
    private String name;
    private double balance;

    // Constructor
    public Customer(int id, String name, double balance) {
        this.id = id;
        this.name = name;
        this.balance = balance;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getBalance() {
        return balance;
    }

    @Override
    public int compareTo(Customer other) {
        // Sorting by id by default
        return Integer.compare(this.id, other.id);
    }

    @Override
    public Customer clone() throws CloneNotSupportedException {
        return (Customer) super.clone();  // Shallow copy
    }

    @Override
    public String toString() {
        return "Customer{id=" + id + ", name='" + name + "', balance=" + balance + '}';
    }
}

